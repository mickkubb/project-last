// Initialize Cloud Firestore through Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseApp = initializeApp({
  apiKey: "AIzaSyAhA0xrAA8AKXYgG8V3URH0KBsphQlVT9k",
  authDomain: "finnal-14172.firebaseapp.com",
  projectId: "finnal-14172",
  storageBucket: "finnal-14172.appspot.com",
  messagingSenderId: "230460773877",
  appId: "1:230460773877:web:4537aedcfb17118ba33cbc",
  measurementId: "G-3Z3L7CZ561"
});

const db = getFirestore(firebaseApp);
const auth = getAuth(firebaseApp);

export { db, auth };
