<template>
  <v-app>
    <v-app-bar app color="indigo lighten-5" white>
      <div class="d-flex align-center">
        <v-img
          alt="Vuetify Logo"
          class="shrink mr-2"
          contain
          src="https://www.pat.nhs.uk/Coronavirus/images/Covid%2019%20Icon.png"
          transition="scale-transition"
          width="50"
        />
      </div>

      <v-spacer></v-spacer>

      <v-btn icon to="/">
        <v-icon>mdi-home</v-icon>
      </v-btn>

      <v-btn icon to="/RegisterUser">
        <v-icon>mdi-account-plus-outline</v-icon>
      </v-btn>

      <v-btn icon to="/Login">
        <v-icon>mdi-login-variant</v-icon>
      </v-btn>
      <v-btn icon to="/About">
        <v-icon>mdi-clipboard-account</v-icon>
      </v-btn>
    </v-app-bar>

    <v-main>
      <router-view />
    </v-main>
  </v-app>
</template>

<script>
export default {
  data: () => ({
    drawer: null,
    items: [
      { title: "Home", icon: "mdi-home", to: "/" },

      { title: "login", icon: "mdi-login", to: "/Login" },
      {
        title: "Register",
        icon: "mdi-registered-trademark",
        to: "/RegisterUser",
      },
      { title: "admin", icon: "mdi-laptop", to: "/about" },
    ],
  }),
};
</script>
